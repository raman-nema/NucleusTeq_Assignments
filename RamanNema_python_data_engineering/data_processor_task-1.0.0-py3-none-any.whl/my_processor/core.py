from .utils import (
    InvalidMemberDataError,
    clean_string,
    validate_email,
    validate_phone,
    format_phone,
    filter_members_by_email
)

class Member:
    def __init__(self, name, email, phone):
        self.name = (name)
        self.email = (email)
        self.phone = (phone)
    
    def __str__(self):
        return f"Member(name={self.name}, email={self.email}, phone={self.phone})"


def process_member(raw_member):
    try:
        name = clean_string(raw_member["name"])
        email = clean_string(raw_member["email"])
        phone = clean_string(raw_member["phone"])

        name = name[:50]  # Limit name to 50 characters

        if not name:
            raise InvalidMemberDataError("Name cannot be empty")

        if not validate_email(email):
            raise InvalidMemberDataError(f"Invalid email: {email}")
        
        if not validate_phone(phone):
            raise InvalidMemberDataError(f"Invalid phone: {phone}")


        return Member(name, email, phone)
    
    except KeyError as error:
        raise InvalidMemberDataError(f"Missing required field: {error}")

def process_members(raw_members):
    processed_members = []
    for raw_member in raw_members:
        name = raw_member.get(
                "name",
                "Invalid data"
        )

        print(
                f"Processing member: {name}...",
                end=""
        )

        try:

            member = process_member(raw_member)
            processed_members.append(member)
            print("Validation Successful.")

        except InvalidMemberDataError as error:
            print(
                f"Error: {error}. Skipping."
                )

        except ValueError as error:
            print(
                f"Error: {error}. Skipping."
                )

        except Exception as error:
            print(
                f"Unexpected error: {error}. Skipping."
                )

    print(
            f"\nSummary: {len(processed_members)} "
            f"members processed successfully."
            )

    return processed_members


def run_processor():

    raw_members = [

            {
            "name": "John Doe",
            "email": "john.doe@example.com",
            "phone": "555-0101"
            },

            {
            "name": "Jane Smith",
            "email": "jane.smith@example.com",
            "phone": "555-0102"
            },

            {
            "name": "InvalidData",
            "email": "invalid...com",
            "phone": "555-0103"
            },

            {
            "name": "Bob Brown",
            "email": "bob.brown@example.com",
            "phone": "555-0104"
            }

    ]

    members = process_members(raw_members)

    print("\nProcessed Members:")

    for member in members:
        print(member)

    print("\nMembers from example.com:")

    example_members = filter_members_by_email(
        members,
        "@example.com"
    )

    for member in example_members:
        print(member)

    return members


if __name__ == "__main__":
    run_processor()



