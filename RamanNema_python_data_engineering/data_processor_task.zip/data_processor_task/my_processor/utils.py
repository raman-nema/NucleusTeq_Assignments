import re

class InvalidMemberDataError(Exception):
    """Custom exception for invalid member data."""
    pass

def clean_string(value):
    if not isinstance(value, str):
        raise ValueError("Input must be a string")
    return value.strip()

def validate_email(email):
    pattern = r"^[\w\.-]+@[\w\.-]+\w+$"
    return re.match(pattern, email) is not None

def validate_phone(phone):
    pattern = r"^\d{3}-\d{4}$"
    return re.match(pattern, phone) is not None

def format_phone(phone):
    return phone.strip().replace("-", "")

def filter_members_by_email(members, domain):
    return list(
        filter(
            lambda member: domain in member.email,
            members
        )
    )