from setuptools import setup, find_packages

setup(
    name = "data_processor_task",
    version = "1.0.0",
    description = "A python training assignment project for data processing and validation.",
    packages = find_packages(),
    python_requires = ">=3.8",
)