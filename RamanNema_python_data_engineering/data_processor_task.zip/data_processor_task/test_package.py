from my_processor.core import Member
from my_processor.utils import validate_email


member = Member(
    "John Doe",
    "john@example.com",
    "555-0101"
)

print("Package imported successfully!")
print("Member:", member)
print("Email valid:", validate_email(member.email))